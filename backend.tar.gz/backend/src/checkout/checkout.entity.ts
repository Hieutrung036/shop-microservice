// Chưa cần entity cho checkout, chỉ dùng service/controller lấy cart
